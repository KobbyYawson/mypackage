# mypackage
This library was created as an example of how to publish your own Python package

## Building this package locally
python.setup.py sdist

## Installation
pip install git+https://github.com/KobbyYawson/example-python-package.git

## Updating package from Github
pip install --upgrade git+https://github.com/KobbyYawson/example-python-package.git